/*
** JNetLib
** Copyright (C) 2000-2001 Nullsoft, Inc.
** Author: Justin Frankel
** File: asyncdns.h - JNL portable asynchronous DNS interface
** License: zlib
**
** Usage:
**   1. Create JNL_AsyncDNS object, optionally with the number of cache entries.
**   2. call resolve() to resolve a hostname into an address. The return value of 
**      resolve is 0 on success (host successfully resolved), 1 on wait (meaning
**      try calling resolve() with the same hostname in a few hundred milliseconds 
**      or so), or -1 on error (i.e. the host can't resolve).
**   4. enjoy.
*/

// Reviewed for Unicode support by Jim Park -- 08/16/2007
// Note: Inet host name is strictly ANSI, no UNICODE for now.

#ifndef _ASYNCDNS_H_
#define _ASYNCDNS_H_

class JNL_AsyncDNS
{
public:
  JNL_AsyncDNS(int max_cache_entries=64);
  ~JNL_AsyncDNS();

  int resolve(char *hostname, unsigned long *addr); // return 0 on success, 1 on wait, -1 on unresolvable

private:
  char m_hostname[256];
  unsigned long m_addr;

  volatile int m_thread_kill;
  HANDLE m_thread;
  static DWORD WINAPI _threadfunc(LPVOID _d);

};

#endif //_ASYNCDNS_H_

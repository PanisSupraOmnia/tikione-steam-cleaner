// Reviewed for Unicode support by Jim Park -- 08/17/2007

#define _WIN32_IE 0x0400
#include <windows.h>

#ifndef IDC_STATIC
#define IDC_STATIC -1
#endif

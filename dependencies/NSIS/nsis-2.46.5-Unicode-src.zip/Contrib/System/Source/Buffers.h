#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef BUFFERS_H
#define BUFFERS_H

#endif /* BUFFERS_H */
